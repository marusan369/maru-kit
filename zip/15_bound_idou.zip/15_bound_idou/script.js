const img = document.getElementById('targetImage');
const speed = 8; // 動きのスピード（お好みで調整してください）

// 画像の読み込みを待つ
window.addEventListener('load', () => {
    // ★CSSで縮小された実際の表示サイズ（幅と高さ）を取得する
    const rect = img.getBoundingClientRect();
    const imgWidth = rect.width;
    const imgHeight = rect.height;

    // 画面内に収まるランダムな初期位置を計算
    let posX = Math.random() * (window.innerWidth - imgWidth);
    let posY = Math.random() * (window.innerHeight - imgHeight);

    let dirX = (Math.random() < 0.5 ? -1 : 1) * speed;
    let dirY = (Math.random() < 0.5 ? -1 : 1) * speed;

    // 初期位置をセット
    img.style.left = posX + 'px';
    img.style.top = posY + 'px';

    // ★位置が決まったので透明を解除して表示する
    img.style.opacity = 1;

    function move() {
        posX += dirX;
        posY += dirY;

        // 画面端で方向を変える（実際の表示サイズを基準にする）
        if (posX <= 0 || posX >= window.innerWidth - imgWidth) dirX *= -1;
        if (posY <= 0 || posY >= window.innerHeight - imgHeight) dirY *= -1;

        img.style.left = posX + 'px';
        img.style.top = posY + 'px';

        requestAnimationFrame(move);
    }

    move();
});