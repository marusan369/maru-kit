document.addEventListener('DOMContentLoaded', () => {
  const target = document.getElementById('targetImage');
  const shakeRange = 8; // 震える幅（px）
  const shakeInterval = 60; // ガクガクするスピード（ms）

  function startRandomShake() {
    setInterval(() => {
      // 1. たまに一瞬だけ消える判定（例：約8%の確率で透明度を0にする）
      // 確率を調整したい場合は Math.random() < 0.05（5%）などに変更できます
      const isGlitching = Math.random() < 0.08;
      
      if (isGlitching) {
        target.style.opacity = '0';
      } else {
        target.style.opacity = '1';
        
        // 2. 通常のガクガク移動処理
        const offsetX = (Math.random() - 0.5) * (shakeRange * 2);
        const offsetY = (Math.random() - 0.5) * (shakeRange * 2);
        const rotateDeg = (Math.random() - 0.5) * 4;

        target.style.transform = `translate(-50%, -50%) translate(${offsetX}px, ${offsetY}px) rotate(${rotateDeg}deg)`;
      }
      
    }, shakeInterval);
  }

  if (target.complete) {
    startRandomShake();
  } else {
    target.addEventListener('load', startRandomShake);
  }
});