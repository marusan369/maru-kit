const img = document.getElementById('targetImage');

function startFloating() {
    // 画面の横幅の範囲内でランダムな横位置を決める
    const randomX = Math.random() * (window.innerWidth - 150);
    img.style.left = randomX + 'px';

    // 登るスピード（4秒〜7秒）
    const duration = 4 + Math.random() * 3;
    img.style.animation = `floatUp ${duration}s ease-in-out forwards`;

    // 登りきった後の待機時間（0.5〜2秒）
    const nextInterval = (0.5 + Math.random() * 2) * 1000;

    setTimeout(() => {
        img.style.animation = 'none';
        setTimeout(startFloating, 50);
    }, duration * 1000 + nextInterval);
}

// 読み込み完了後にスタート
window.addEventListener('load', () => {
    setTimeout(startFloating, 500);
});