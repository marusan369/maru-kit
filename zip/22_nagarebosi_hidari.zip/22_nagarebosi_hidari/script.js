const container = document.querySelector('.material-container');

function spawnShootingStar() {
    // 1. 新しい <img> 要素を動的に作る
    const img = document.createElement('img');
    img.src = 'target.png';
    img.className = 'shooting-star';
    container.appendChild(img);

    // 2. スタート位置：画面の「右上さらに外側」
    // X軸：画面の右端よりさらに右（105%〜125%の位置）
    const startX = window.innerWidth * 1.05 + (Math.random() * (window.innerWidth * 0.2));
    // Y軸：画面の上部さらに外側（-40%〜-20%の位置）
    const startY = -window.innerHeight * 0.4 + (Math.random() * (window.innerHeight * 0.2));

    // 3. ゴール位置：画面の「左下さらに外側」
    // X軸：画面の左端よりさらに左（-40%〜-20%の位置）
    const endX = -window.innerWidth * 0.4 + (Math.random() * (window.innerWidth * 0.2));
    // Y軸：画面の下端よりさらに下（105%〜125%の位置）
    const endY = window.innerHeight * 1.05 + (Math.random() * (window.innerHeight * 0.2));

    // 4. 計算した開始位置を適用
    img.style.left = startX + 'px';
    img.style.top = startY + 'px';

    // 5. 終点までの移動距離をCSS変数にセット
    img.style.setProperty('--endX', (endX - startX) + 'px');
    img.style.setProperty('--endY', (endY - startY) + 'px');

    // 6. スピード（8秒〜12秒）
    const duration = 8 + Math.random() * 4;
    img.style.animation = `shootDiagonal ${duration}s cubic-bezier(0.22, 0.61, 0.36, 1) forwards`;

    // 7. アニメーションが終わったら要素を削除
    setTimeout(() => {
        img.remove();
    }, duration * 1000);
}

// 読み込み完了後にスタート
window.addEventListener('load', () => {
    // 最初からHTMLにある #targetImage があればそれも流れ星クラスにする
    const firstImg = document.getElementById('targetImage');
    if (firstImg) {
        firstImg.className = 'shooting-star';
    }

    // 最初の1個をすぐ出す
    spawnShootingStar();

    // 一定間隔で次々と発生させる
    setInterval(() => {
        spawnShootingStar();
    }, (1 + Math.random() * 2) * 1000);
});