const container = document.querySelector('.material-container');

// 画像にアニメーションを適用して、終わったら消す共通関数
function animateImage(img, duration) {
    const randomX = Math.random() * (window.innerWidth - 150);
    img.style.left = randomX + 'px';
    img.style.animation = `fallDown ${duration}s ease-in-out forwards`;

    setTimeout(() => {
        img.remove();
    }, duration * 1000);
}

// 新しい画像を動的に作ってスポーンする関数
function spawnImage() {
    const img = document.createElement('img');
    img.src = 'target.png';
    container.appendChild(img);

    // 落ちるスピード（6秒〜10秒）
    const duration = 6 + Math.random() * 4;
    animateImage(img, duration);
}

// ページ読み込み完了後にスタート
window.addEventListener('load', () => {
    // 1. 最初からHTMLにある画像（#targetImage）を最初の1個目として動かす
    const firstImg = document.getElementById('targetImage');
    if (firstImg) {
        const duration = 4 + Math.random() * 3;
        animateImage(firstImg, duration);
    }

    // 2. 一定間隔（0.5秒〜2秒おき）で、次々と新しい画像を発生させる
    setInterval(() => {
        spawnImage();
    }, (0.5 + Math.random() * 2) * 1000);
});