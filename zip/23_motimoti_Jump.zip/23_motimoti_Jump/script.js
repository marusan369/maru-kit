const container = document.querySelector('.material-container');

function spawnJumpingItem() {
    // 1. 新しい <img> 要素を動的に作る
    const img = document.createElement('img');
    img.src = 'target.png';
    img.className = 'jump-item';
    container.appendChild(img);

    // 2. 画面の横幅の範囲内でランダムな横位置を決める
    const randomX = Math.random() * (window.innerWidth - 150);
    img.style.left = randomX + 'px';

    // 3. ジャンプのスピード（例：3秒〜5秒）
    const duration = 3 + Math.random() * 2;
    img.style.animation = `jumpAnimation ${duration}s ease-in-out forwards`;

    // 4. アニメーションが終わったら要素を削除
    setTimeout(() => {
        img.remove();
    }, duration * 1000);
}

// 読み込み完了後にスタート
window.addEventListener('load', () => {
    const container = document.querySelector('.material-container');
    let target = document.getElementById('targetImage');

    // もしHTMLに最初から画像タグがない場合は、自動で作成して配置する
    if (!target) {
        target = document.createElement('img');
        target.src = 'target.png';
        container.appendChild(target);
    }
    
    target.className = 'center-jump-item';
});
    }

    // 最初の1個をすぐ出す
    spawnJumpingItem();

    // 1.5秒〜3秒おきに次々とピョンピョン飛び出させる
    setInterval(() => {
        spawnJumpingItem();
    }, (1.5 + Math.random() * 1.5) * 1000);
});