document.addEventListener("DOMContentLoaded", () => {
  // 現時点ではCSSアニメーションで動作しますが、
  // 今後ランダムな初期位置や周期を持たせる場合の処理をここに記述できます。
});