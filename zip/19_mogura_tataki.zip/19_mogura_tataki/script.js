const img = document.getElementById('targetImage');

function moleAction() {
    // 1. 画面の横幅の範囲内でランダムな横位置を決める
    const randomX = Math.random() * (window.innerWidth - 120);
    img.style.left = randomX + 'px';

    // 2. ひょっこり飛び出す（CSSの .popクラスをつける）
    img.classList.add('pop');

    // 3. 0.5秒〜2.0秒の間でランダムな滞在時間を決める
    const stayTime = 500 + Math.random() * 1500;

    // 4. 滞在時間が終わったら、引っ込ませる（クラスを外す）
    setTimeout(() => {
        img.classList.remove('pop');

        // 5. 引っ込んだあと、次の出現までの間隔をランダム（1秒〜3秒）に決めて次の動作へ
        const nextInterval = 1000 + Math.random() * 2000;
        setTimeout(moleAction, nextInterval);

    }, 300 + stayTime); // 300ms（飛び出しにかかる時間）＋ 滞在時間
}

// ページ読み込み完了後にスタート
window.addEventListener('load', () => {
    setTimeout(moleAction, 1000);
});