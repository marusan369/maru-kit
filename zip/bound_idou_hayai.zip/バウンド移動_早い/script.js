const img = document.getElementById('targetImage');
const speed = 10; // ピクセル/フレーム

// 画像が読み込まれてからサイズを取得して初期位置を決める
window.addEventListener('load', () => {
    let posX = Math.random() * (window.innerWidth - img.width);
    let posY = Math.random() * (window.innerHeight - img.height);

    let dirX = (Math.random() < 0.5 ? -1 : 1) * speed;
    let dirY = (Math.random() < 0.5 ? -1 : 1) * speed;

    function move() {
        posX += dirX;
        posY += dirY;

        // 画面端で方向を変える
        if (posX <= 0 || posX >= window.innerWidth - img.width) dirX *= -1;
        if (posY <= 0 || posY >= window.innerHeight - img.height) dirY *= -1;

        img.style.left = posX + 'px';
        img.style.top = posY + 'px';

        requestAnimationFrame(move);
    }

    move();
});