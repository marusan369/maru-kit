document.addEventListener('DOMContentLoaded', () => {
  const target = document.getElementById('targetImage');
  const shakeRange = 8; // 震える幅（ピクセル）
  const shakeInterval = 60; // ガクガクするスピード（ミリ秒）

  function startRandomShake() {
    setInterval(() => {
      // 全方位へのランダムなズレ（-shakeRange ～ +shakeRange）
      const offsetX = (Math.random() - 0.5) * (shakeRange * 2);
      const offsetY = (Math.random() - 0.5) * (shakeRange * 2);
      
      // わずかな回転も加えるとよりガクガク感が出る
      const rotateDeg = (Math.random() - 0.5) * 4;

      // 中央寄せ(-50%, -50%)を維持したまま、ズレと回転を適用
      target.style.transform = `translate(-50%, -50%) translate(${offsetX}px, ${offsetY}px) rotate(${rotateDeg}deg)`;
      
    }, shakeInterval);
  }

  // 画像が読み込まれていれば即座に開始、なければロードを待つ
  if (target.complete) {
    startRandomShake();
  } else {
    target.addEventListener('load', startRandomShake);
  }
});