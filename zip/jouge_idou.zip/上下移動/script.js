// 今回はCSSアニメーション主体のため、読み込み確認や動的な処理の土台として記載しています
window.addEventListener('DOMContentLoaded', () => {
  const img = document.getElementById('targetImage');
  
  // 画像の読み込みエラー対策（ファイル名違いなどのチェック用）
  img.addEventListener('error', () => {
    console.error('指定された画像ファイルが見つかりません。「image1.png」等を確認してください。');
  });
});