const container = document.querySelector('.material-container');

function spawnShootingStar() {
    // 1. 新しい <img> 要素を動的に作る
    const img = document.createElement('img');
    img.src = 'target.png';
    img.className = 'shooting-star';
    container.appendChild(img);

    // 2. スタート位置：画面の左上「さらに外側」（画像サイズ25vhが完全に隠れる位置）
    const startX = -window.innerWidth * 0.4 + (Math.random() * (window.innerWidth * 0.2));
    const startY = -window.innerHeight * 0.4 + (Math.random() * (window.innerHeight * 0.2));

    // 3. ゴール位置：画面の右下「さらに外側」へ完全に突き抜ける位置
    const endX = window.innerWidth * 1.2 + (Math.random() * (window.innerWidth * 0.2));
    const endY = window.innerHeight * 1.2 + (Math.random() * (window.innerHeight * 0.2));

    // 4. 計算した開始位置を適用
    img.style.left = startX + 'px';
    img.style.top = startY + 'px';

    // 5. 終点までの移動距離をCSS変数にセット
    img.style.setProperty('--endX', (endX - startX) + 'px');
    img.style.setProperty('--endY', (endY - startY) + 'px');

    // 6. スピード（アニメーション時間）をランダムに設定（例：8秒〜20秒）
    const duration = 8 + Math.random() * 12;
    img.style.animation = `shootDiagonal ${duration}s cubic-bezier(0.22, 0.61, 0.36, 1) forwards`;

    // 7. アニメーションが終わったら要素を削除
    setTimeout(() => {
        img.remove();
    }, duration * 1000);
}

// 読み込み完了後にスタート
window.addEventListener('load', () => {
    // 最初からHTMLにある #targetImage があればそれも流れ星クラスにする
    const firstImg = document.getElementById('targetImage');
    if (firstImg) {
        firstImg.className = 'shooting-star';
    }

    // 最初の1個をすぐ出す
    spawnShootingStar();

    // 1秒〜3秒おきに次々と斜め降る画像を発生させる
    setInterval(() => {
        spawnShootingStar();
    }, (1 + Math.random() * 2) * 1000);
});